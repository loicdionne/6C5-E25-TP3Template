# com.unity.ml-agents

ML-Agents is a Unity package that allows users to use state-of-the-art machine learning to create intelligent character behaviors in any Unity environment (games, robotics, film, etc.).

## Installation

Please refer to the [ML-Agents github repo] for installation instructions.

## Usage

Please refer to the [ML-Agents documentation] page for usage guides.


[ML-Agents github repo]: https://github.com/Unity-Technologies/ml-agents
[ML-Agents documentation]: https://unity-technologies.github.io/ml-agents/
