using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.ML-Agents.Extensions.Input.Tests.Runtime")]
