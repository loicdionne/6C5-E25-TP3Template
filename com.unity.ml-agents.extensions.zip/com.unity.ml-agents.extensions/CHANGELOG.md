# Changelog
This changelog isn't used; please add to the `com.unity.ml-agents` changelog instead.

## [Unreleased]
## [0.6.1-preview] - 2022-11-21
 * Initial version
